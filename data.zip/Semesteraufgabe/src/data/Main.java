package data;

public class Main {
	
	public static void main(String [] args){
		Film s = new Film("Der weiße Hai", "S. Spielberg", 1978, false, 10);
		System.out.println();
		
		//Verwaltung container = Verwaltung.instance();
		
		
	}
}
