package GUIImplementierung;

public class Main {
	public static void main( String args[]) {
		Hauptfenster neuesfenster = new Hauptfenster();
	}

}
